<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="refresh" content="1;url=https://dichvufb.net" />

        <title>Redirecting to https://dichvufb.net</title>
    </head>
    <body>
        Redirecting to <a href="https://dichvufb.net">https://dichvufb.net</a>.
    </body>
</html>